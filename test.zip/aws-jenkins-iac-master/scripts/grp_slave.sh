#!/bin/bash
set -o xtrace

mkdir /nyl
mkfs -t ext4 /dev/nvme1n1
mount /dev/nvme1n1 /nyl
echo "/dev/nvme1n1       /nyl   auto    defaults     0       0"  >> /etc/fstab
echo "setupssh key"
sudo ssh-keygen -N "" -f ~/.ssh/id_rsa
sudo chmod 700 .ssh
cd .ssh
cat id_rsa.pub >> ~/.ssh/authorized_keys
less id_rsa
#chmod 600 id_rsa  authorized_keys
echo "Java Installation "
sudo yum install java-11-openjdk-devel -y
echo 'Make directory Java'
mkdir /opt/java
echo 'Move Java Home at app Level'
sudo cp -avr /usr/lib/jvm/java-11-openjdk-11.* /opt/java
echo "Installing Nodejs"
sudo yum install -y nodejs
echo "Installing Git"
sudo yum install -y git
echo "Installing maven"
echo "Installing maven"
mkdir /nyl/maven
cd /nyl/maven
wget http://apache.mirrors.hoobly.com/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.tar.gz
tar -zxvf apache-maven-3.6.3-bin.tar.gz
cd /nyl
echo "Installing Sonar Runner"
sudo wget https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-4.4.0.2170-linux.zip
sudo unzip  sonar-scanner-cli-4.4.0.2170-linux.zip
sudo mv  sonar-scanner-4.4.0.2170-linux/ sonar-scanner/
echo "Configuring Sonar scanner properties"
sudo sed -i 's|#sonar.host.url=http://localhost:9000|sonar.host.url=https://${env}.sq.nylcloud.com/sonar|g' /nyl/sonar-scanner/conf/sonar-scanner.properties
echo "Setting JAVA_HOME environment variable"
sudo sed -i -e '$a export JAVA_HOME=/opt/java/java-11-openjdk-11.*' ~/.bashrc
echo "Setting MAVEN environment variable"
sudo sed -i -e '$a export M2_HOME=/nyl/maven/apache-maven-3.6.3' ~/.bashrc
sudo sed -i -e '$a export M2=$M2_HOME/bin' ~/.bashrc
echo "Pushing JAVA_HOME and M2_HOME to Path variable"
sudo sed -i -e '$a PATH=$JAVA_HOME/bin:$M2:nyl/sonar-scanner/bin:$PATH' ~/.bashrc
echo 'refresh the sys variables'
source ~/.bashrc

echo "install javaquery tool to split the json"
sudo yum install jq -y
sudo mkdir /nyl/datapower
sudo chmod 777 /nyl/datapower/ -R
cd /nyl/datapower
echo "split the json to digi cert"
aws secretsmanager list-secrets --query "SecretList[?starts_with(Name,'devtools-${env}-jenkins-datapower')]" | sort -r | grep Name -m1 | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e "s/.$//" -e "s/.$//" > dpsmout.txt
sudo sed -i 's|"Name": "devtools|devtools|g' dpsmout.txt
aws secretsmanager get-secret-value --secret-id "$(cat dpsmout.txt)"  | jq --raw-output '.SecretString' | jq -r .cert > jfrog.www.jfrog-alm.client.newyorklife.com.cer.txt
echo "split the json to private key"
aws secretsmanager get-secret-value --secret-id "$(cat dpsmout.txt)"  | jq --raw-output '.SecretString' | jq -r .pkey > jfrog.www.jfrog-alm.client.newyorklife.com.key.txt
echo "decode the .cer and .key files"
echo "$(cat jfrog.www.jfrog-alm.client.newyorklife.com.cer.txt)" | base64 --decode > jfrog.www.jfrog-alm.client.newyorklife.com.cer
echo "$(cat jfrog.www.jfrog-alm.client.newyorklife.com.key.txt)" | base64 --decode > jfrog.www.jfrog-alm.client.newyorklife.com.key
echo "convert into .p12 file"
openssl pkcs12 -export -inkey ./jfrog.www.jfrog-alm.client.newyorklife.com.key -in jfrog.www.jfrog-alm.client.newyorklife.com.cer -out jfrog.www.jfrog-alm.client.newyorklife.com.p12 -name newyorklife -password pass:changeit
#need to change the line once JAVA_HOME properly set
sudo /opt/java/java-11-openjdk-11.*/bin/keytool -import -alias datapower-cert -keystore /opt/java/java-11-openjdk-11.*/lib/security/cacerts -file /nyl/datapower/jfrog.www.jfrog-alm.client.newyorklife.com.cer -storepass changeit -noprompt
echo "get the ssh pub key from secrets manager master 01"
aws secretsmanager get-secret-value --secret-id devtools-${env}-jenkins-grp-master-01-ssh --query SecretString --output text > id_rsa_master.pub
echo "trim the pub at start"
sudo sed -i "s/^{id_rsa.pub:ssh-rsa/ssh-rsa/" id_rsa_master.pub
echo "trim the pub at end"
sudo sed -i "s/.$//" id_rsa_master.pub
cat id_rsa_master.pub >> ~/.ssh/authorized_keys
echo "get the ssh pub key from secrets manager master 02"
aws secretsmanager get-secret-value --secret-id devtools-${env}-jenkins-grp-master-02-ssh --query SecretString --output text > id_rsa_master_02.pub
echo "trim the pub at start"
sudo sed -i "s/^{id_rsa.pub:ssh-rsa/ssh-rsa/" id_rsa_master_02.pub
echo "trim the pub at end"
sudo sed -i "s/.$//" id_rsa_master_02.pub
cat id_rsa_master_02.pub >> ~/.ssh/authorized_keys
sudo mkdir /nyl/jenkinsWS
sudo mkdir /nyl/jenkinsWS/.m2
sudo mkdir /nyl/jenkinsWS/.m2/repository
sudo chmod 777 /nyl/jenkinsWS/ -R
#need to call $MAVEN_HOME/conf
cd /nyl/maven/apache-maven-3.6.3/conf
sudo chmod 777 /nyl/maven/apache-maven-3.6.3/conf/ -R
sudo mv settings.xml settings_old.xml
echo "handle settings.xml from sm"
aws secretsmanager create-secret --name devtools-${env}-jenkins-slave-maven
aws secretsmanager get-secret-value --secret-id devtools-${env}-jenkins-slave-maven | jq --raw-output '.SecretString' >> settings.xml
sudo su - ec2-user
echo "Setting JAVA_HOME environment variable"
sudo sed -i -e '$a export JAVA_HOME=/opt/java/java-11-openjdk-11.*' ~/.bashrc
echo "Setting MAVEN environment variable"
sudo sed -i -e '$a export M2_HOME=/nyl/maven/apache-maven-3.6.3' ~/.bashrc
sudo sed -i -e '$a export M2=$M2_HOME/bin' ~/.bashrc
echo "Pushing JAVA_HOME and M2_HOME to Path variable"
sudo sed -i -e '$a PATH=$JAVA_HOME/bin:$M2:nyl/sonar-scanner/bin:$PATH' ~/.bashrc
echo "refresh the sys variables"
source ~/.bashrc
cd /nyl/datapower
sudo su -c 'cat id_rsa_master.pub >> ~/.ssh/authorized_keys' ec2-user
