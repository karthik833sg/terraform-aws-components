<runAsLocalSystem>true</runAsLocalSystem>
<powershell>
ECHO "Installing the Oracle Java Virtual Machine"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# Working directory path
    $WORKD = "C:\AgentConfig"

# Check if work directory exists if not create it
    If (!(Test-Path -Path $WORKD -PathType Container))
    {
    New-Item -Path $WORKD  -ItemType directory
    }

#create config file for silent install
    $TEXT = '
    INSTALL_SILENT=Enable
    AUTO_UPDATE=Enable
    SPONSORS=Disable
    REMOVEOUTOFDATEJRES=1
    '
    $TEXT | Set-Content "$WORKD\jreinstall.cfg"

#download executable
    $JAVA_URL = "https://javadl.oracle.com/webapps/download/AutoDL?xd_co_f=ZTgyYTFjYWYtMmE3OS00YjllLWFhZTgtNzZmNjcxNWU3NDky&BundleId=242990_a4634525489241b9a9e1aa73d9e118e6"
    $JAVA_DESTINATION = "$WORKD\jreInstall.exe"
    $CLIENT = New-Object System.Net.WebClient
    $CLIENT.DownloadFile($JAVA_URL, $JAVA_DESTINATION)

#install silently
    Start-Process -FilePath "$WORKD\jreInstall.exe" -ArgumentList INSTALLCFG="$WORKD\jreinstall.cfg"
    Start-Sleep -s 180

ECHO "Java installation is done"

# Remove the installer
    rm -Force $WORKD\jre*

ECHO "Creating User Account"

    $PW = ConvertTo-SecureString -String "sshd_P@ssw0rd" -AsPlainText -Force
    New-LocalUser -Name sshd -Password $PW -PasswordNeverExpires -AccountNeverExpires
    Add-LocalGroupMember -Group Administrators -Member sshd

ECHO "Installing cygwin"
    Invoke-WebRequest https://cygwin.com/setup-x86_64.exe -OutFile C:\AgentConfig\setup-x86_64.exe
    Start-Process C:\AgentConfig\setup-x86_64.exe -Wait -NoNewWindow -ArgumentList "-q -n -l C:\cygwin64\packages -s http://mirrors.kernel.org/sourceware/cygwin/ -R C:\cygwin64 -P python-devel,openssh,cygrunsrv,wget,tar,qawk,bzip2,subversion,vim,make,gcc-fortran,gcc-g++,gcc-core,make,openssl,openssl-devel,libffi-devel,libyaml-devel,git,zip,unzip,gdb,libsasl2,gettext"
    Remove-Item C:\AgentConfig\setup-x86_64.exe

ECHO "Setting Cygwin on PATH"
    $newPath = 'C:\cygwin64\bin;\cygwin\bin;' + [Environment]::GetEnvironmentVariable("PATH", [EnvironmentVariableTarget]::Machine)
    [Environment]::SetEnvironmentVariable("PATH", $newPath, [EnvironmentVariableTarget]::Machine)

ECHO "Setting up Cygwin"
    Start-Process C:\cygwin64\bin\bash.exe -Wait -NoNewWindow -ArgumentList "C:\cygwin64\bin\ssh-host-config --yes -c '' -u sshd -w sshd_password"

ECHO "Creating pub keys and adding it to authorized_keys"
    MKDIR C:\cygwin64\home\Administrator\.ssh
    C:\cygwin64\bin\ssh-keygen.exe -m pem -t ecdsa -f /home/Administrator/win_keys -q -N '""'
    cd C:\cygwin64\home\Administrator\.ssh
    C:\cygwin64\bin\cp.exe  /home/Administrator/win_keys.pub /home/Administrator/.ssh/authorized_keys
    chmod 700 /home/Administrator/.ssh
    chmod 640 /home/Administrator/.ssh/authorized_keys
    chown -R Administrator /home/Administrator

ECHO "Starting the CYGWIN sshd service from the Services management panel"
    Write-Host "Start sshd service"
    net start cygsshd

ECHO "Opening and configuring Windows Firewall"
    Write-Host "Setting firewall rule"
    netsh advfirewall firewall add rule name="ssh" dir=in action=allow protocol=TCP localport=22

# Setting up tools Properties
	$SONAR_HOME = 'C:\sonar-scanner'
	$SONAR_FILE = 'sonar-scanner-msbuild.zip'
	$SONAR_URL = 'https://github.com/SonarSource/sonar-scanner-msbuild/releases/download/4.10.0.19059/sonar-scanner-msbuild-4.10.0.19059-net46.zip'
	$SONAR_VERSION = 'sonar-scanner-4.4.0.2170'
	$MAVEN_HOME = 'C:\maven'
	$MAVEN_FILE = 'maven.zip'
	$MAVEN_VERSION= 'apache-maven-3.6.3'
	$MAVEN_URL = 'https://mirror.dsrg.utoronto.ca/apache/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.zip'
	$NODEJS_URL = 'https://nodejs.org/dist/v12.18.4/node-v12.18.4-x64.msi'
	$NODEJS_FILE = 'node-v12.18.4-x64.msi'

ECHO "Creating sonar scanner folder"
    MKDIR $SONAR_HOME

ECHO "Downloading Sonnar scanner for MSBuild"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $SONAR_URL -OutFile "$WORKD\$SONAR_FILE"

ECHO "Extracting sonar-scanner"
    Add-Type -assembly "system.io.compression.filesystem"
    [System.IO.Compression.ZipFile]::ExtractToDirectory("$WORKD\$SONAR_FILE","$SONAR_HOME")

ECHO "Adjusting Sonnar scanner Properties"
    (Get-Content $SONAR_HOME\$SONAR_VERSION\conf\sonar-scanner.properties) -replace '#sonar.host.url=http://localhost:9000', 'sonar.host.url=https://${env}.sq.nylcloud.com/sonar' | Set-Content C:\sonar-scanner\sonar-scanner-4.4.0.2170\conf\sonar-scanner.properties

ECHO "Creating maven folder"
    mkdir $MAVEN_HOME

ECHO "Downloading Maven"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $MAVEN_URL -OutFile "$WORKD\$MAVEN_FILE"

ECHO "Extracting maven"
    Add-Type -assembly "system.io.compression.filesystem"
    [System.IO.Compression.ZipFile]::ExtractToDirectory("$WORKD\$MAVEN_FILE","$MAVEN_HOME")

ECHO "Downloading NodeJS"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $NODEJS_URL -OutFile "$WORKD\$NODEJS_FILE"

ECHO "Installing NodeJS"
    msiexec /qn /l* C:\AgentConfig\node-log.txt /i $WORKD\$NODEJS_FILE

# Wait 60 Seconds for the installation to finish
    Start-Sleep -s 60

ECHO "Installing GIT"
#Activating Chocolatey
	Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
#Install GIT
	choco install git -y
ECHO "Setting Jenkins folder"
MKDIR C:\Jenkins 

ECHO "Setting up PATH for Maven and Sonar-Scanner"
    $newPath = "$SONAR_HOME;$MAVEN_HOME\$MAVEN_VERSION\bin;" + [Environment]::GetEnvironmentVariable("PATH", [EnvironmentVariableTarget]::Machine)
[Environment]::SetEnvironmentVariable("PATH", $newPath, [EnvironmentVariableTarget]::Machine)

ECHO "Server setup is completed"
ECHO "Run CAT C:\cygwin64\home\Administrator\.ssh\win_key.pub to get the private key and configure Windows Agent from Jenkins"
</powershell>
