#!/bin/bash
exec &> /home/ec2-user/logfile.txt
mkdir /nyl
mkfs -t ext4 /dev/nvme1n1
mount /dev/nvme1n1 /nyl
echo "/dev/nvme1n1       /nyl   auto    defaults     0       0"  >> /etc/fstab
echo "NFS Mounting"
sudo mkdir /var/lib/jenkins
sudo yum -y install nfs-utils
sudo systemctl start nfs
sudo sed -i -e '$a ${mount_point}:/ /var/lib/jenkins nfs4 nfsvers=4.1,rsize=1048576,hard,timeo=600,retrans=2    0 0' /etc/fstab
sudo mount -a

echo "Installing JAVA"
sudo yum remove -y java
sudo yum install -y java-1.8.0-openjdk
echo "Downloading Jenkins CJE"
sudo wget -O /etc/yum.repos.d/jenkins.repo https://downloads.cloudbees.com/jenkins-enterprise/rolling/rpm/jenkins.repo
sudo rpm --import https://downloads.cloudbees.com/jenkins-enterprise/rolling/rpm/cloudbees.com.key
echo "Installing Jenkins CJE"
sudo yum install jenkins -y
#sudo sed -i 's/JENKINS_JAVA_OPTIONS="-Djava.awt.headless=true"/JENKINS_JAVA_OPTIONS="-Djava.awt.headless=true -Xmx4096m -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+ParallelRefProcEnabled -XX:+DisableExplicitGC  -XX:+UnlockDiagnosticVMOptions  -XX:+UnlockExperimentalVMOptions -verbose:gc -Xloggc:/var/lib/jenkins/gc/gc-%t.log -XX:NumberOfGCLogFiles=2 -XX:+UseGCLogFileRotation -XX:GCLogFileSize=100m -XX:+PrintGC -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+PrintHeapAtGC -XX:+PrintGCCause -XX:+PrintTenuringDistribution -XX:+PrintReferenceGC -XX:+PrintAdaptiveSizePolicy -XX:+AlwaysPreTouch -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/lib/jenkins/gc -Djava.net.preferIPv4Stack=true"/g' /etc/sysconfig/jenkins
sudo sed -i 's|JENKINS_JAVA_OPTIONS="-Djava.awt.headless=.*"|JENKINS_JAVA_OPTIONS="-Djava.awt.headless=true -Xmx4096m -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+ParallelRefProcEnabled -XX:+DisableExplicitGC  -XX:+UnlockDiagnosticVMOptions  -XX:+UnlockExperimentalVMOptions -verbose:gc -Xloggc:/var/lib/jenkins/gc/gc-%t.log -XX:NumberOfGCLogFiles=2 -XX:+UseGCLogFileRotation -XX:GCLogFileSize=100m -XX:+PrintGC -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+PrintHeapAtGC -XX:+PrintGCCause -XX:+PrintTenuringDistribution -XX:+PrintReferenceGC -XX:+PrintAdaptiveSizePolicy -XX:+AlwaysPreTouch -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/lib/jenkins/gc -Djava.net.preferIPv4Stack=true"|g' /etc/sysconfig/jenkins
echo "modifying ulimit values as per cloudbees best practices"
sudo sed -i -e '$ajenkins  		    hard 	  nofile  8192' /etc/security/limits.conf
sudo sed -i -e '$ajenkins     		  soft   	  nofile  4096' /etc/security/limits.conf
sudo sed -i -e '$ajenkins     		   soft  	   nproc   30654' /etc/security/limits.conf
sudo sed -i -e '$ajenkins     		   hard  	   nproc   30654' /etc/security/limits.conf
sudo sed -i 's|* hard core 0|* hard core unlimited|g' /etc/security/limits.conf
sudo service jenkins start
sudo service jenkins status
echo "Getting default password"
sudo chmod 777 /var/lib/jenkins/secrets
sudo cat /var/lib/jenkins/secrets/initialAdminPassword
echo "Changing JENKINS_JAVA_OPTIONS"
echo "Installing Nodejs"
sudo yum install -y nodejs
echo "Installing Git"
sudo yum install -y git
echo "Installing maven"
mkdir /home/ec2-user/maven
cd /home/ec2-user/maven
wget http://apache.mirrors.hoobly.com/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.tar.gz
tar -zxvf apache-maven-3.6.3-bin.tar.gz
echo "store ssh pvt key under secret manager"
aws secretsmanager create-secret --name devtools-${env}-jenkins-ent-master-01-node-02-pvt-ssh
aws secretsmanager update-secret --secret-id devtools-${env}-jenkins-ent-master-01-node-02-pvt-ssh --secret-string {"id_rsa":"$(cat ~/.ssh/id_rsa)"}
sleep 60
aws secretsmanager create-secret --name devtools-${env}-jenkins-ent-master-02-initial-pw
aws secretsmanager update-secret --secret-id devtools-${env}-jenkins-ent-master-02-initial-pw --secret-string {"pw":"$(sudo cat /var/lib/jenkins/secrets/initialAdminPassword)"}
