#!/bin/bash
exec &> /home/ec2-user/logfile.txt
set -o xtrace

mkdir /nyl
mkfs -t ext4 /dev/nvme1n1
mount /dev/nvme1n1 /nyl
echo "/dev/nvme1n1       /nyl   auto    defaults     0       0"  >> /etc/fstab

echo "NFS Mounting"
sudo mkdir /var/lib/jenkins-oc
sudo yum -y install nfs-utils
sudo systemctl start nfs
sudo sed -i -e '$a ${mount_point}:/ /var/lib/jenkins-oc nfs4 nfsvers=4.1,rsize=1048576,hard,timeo=600,retrans=2    0 0' /etc/fstab
sudo mount -a

echo "Java Installation "
sudo yum remove -y java
sudo yum install -y java-1.8.0-openjdk
echo "Downloading Jenkins-OC"
sudo wget -O /etc/yum.repos.d/jenkins-oc.repo https://downloads.cloudbees.com/jenkins-operations-center/rolling/rpm/jenkins-oc.repo
sudo rpm --import https://downloads.cloudbees.com/jenkins-operations-center/rolling/rpm/cloudbees.com.key
sudo yum install jenkins-oc -y
echo "Starting Jenkins-OC"
sudo service jenkins-oc start
echo "Getting default password for Jenkins-OC"
sudo chmod 777 /var/lib/jenkins-oc/secrets
sudo cat /var/lib/jenkins-oc/secrets/initialAdminPassword
echo "Changing JENKINS_JAVA_OPTIONS"
sudo sed -i 's|JENKINS_JAVA_OPTIONS="-Djava.awt.headless=.*"|JENKINS_JAVA_OPTIONS="-Djava.awt.headless=true -Xmx4096m -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+ParallelRefProcEnabled -XX:+DisableExplicitGC  -XX:+UnlockDiagnosticVMOptions  -XX:+UnlockExperimentalVMOptions -verbose:gc -Xloggc:/var/lib/jenkins-oc/gc/gc-%t.log -XX:NumberOfGCLogFiles=2 -XX:+UseGCLogFileRotation -XX:GCLogFileSize=100m -XX:+PrintGC -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+PrintHeapAtGC -XX:+PrintGCCause -XX:+PrintTenuringDistribution -XX:+PrintReferenceGC -XX:+PrintAdaptiveSizePolicy -XX:+AlwaysPreTouch -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/lib/jenkins-oc/gc -Djava.net.preferIPv4Stack=true"|g' /etc/sysconfig/jenkins-oc 
echo "Installing Git"
sudo yum install -y git
echo "Setting ec2-user session"
sudo su - ec2-user
echo "Setting init pw file permission"
sudo chmod 777 /var/lib/jenkins-oc/secrets/ -R
echo "to store initial pw inside sm for joc"
sleep 65
aws secretsmanager create-secret --name devtools-${env}-jenkins-joc-initial-pw
aws secretsmanager update-secret --secret-id devtools-${env}-jenkins-joc-initial-pw --secret-string {"pw":"$(sudo cat /var/lib/jenkins-oc/secrets/initialAdminPassword)"}
