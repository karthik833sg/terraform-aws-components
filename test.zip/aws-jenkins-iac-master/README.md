# aws-jenkins-iac
Infrastructure as Code for NYL Cloudbees Jenkins on AWS

## Platform Customization Dependencies

* nyl-v2-customization-2.1.44

## Pre-Requisites

1. [Automated] Custom security group must be deployed with account in v2-customization module
2. Certificates for the domain names listed in the variables below must be requested and approved in Amazon Certificate Manager
3. Ensure the rhel7 AND win2016 AMIs have been built in the account
4. Turn on the Route53 resolver in the account Terraform workspace (create_resolver = 1)
5. A datapower certificate must be obtained and base64 encoded: `openssl base64 -in <infile> -out <outfile>`. The variable should be entered as HCL using the following format:

```
{
	"cert" = "<base64 encoded certificate file",
	"pkey" = "<base64 encoded private key file"
}
```

## Infrastructure Deployment Instructions

1. Setup PTFE according to the  [PTFE Deployment Guide](https://git.nylcloud.com/pages/Cloud-Team/docs/ptfe_deploy.html)
2. Add required variables
3. Run Terraform
4. Point DNS (names below) at the 4 Elastic Load Balancers (classic)
5. Pull and send jenkins initial passwords from Secret Manager (secret names provided by app team)
6. Provide fire call access to app team

## Required Variables

```
variable "env" {
  type = string
}

# Set to a blank string so no key is used
variable "key_name" {
  type = string
}

variable "assume_role_arn" {
  type = string
}

variable "external_id" {
  type = string
}

variable "joc_domain_name" {
  type = string
}

variable "grp_master1_domain_name" {
  type = string
}

variable "grp_master2_domain_name" {
  type = string
}

variable "nyl_master_domain_name" {
  type = string
}

variable "datapower_cert" {
  type = map
}
```

## DNS Names  

### Jenkins NYL Master 1

* Lower Environments: `${env}.nyl1.jenkins.nylcloud.com`
* Production:  `nyl1.jenkins.nylcloud.com`

### Jenkins GRP Master 1

* Lower Environments: `${env}.grp1.jenkins.nylcloud.com`
* Production:  `grp1.jenkins.nylcloud.com`

### Jenkins GRP Master 2

* Lower Environments: `${env}.grp2.jenkins.nylcloud.com`
* Production:  `grp2.jenkins.nylcloud.com`

### Jenkins Operations Center

* Lower Environments: `${env}.jenkinsoc.nylcloud.com`
* Production:  `jenkinsoc.nylcloud.com`

## PTFE workspaces

  * Dev: https://ptfe.nylcloud.com/app/nyl-devtools-dev/workspaces/aws-devtools-dev-jenkins-us-east-1/runs
  * QA:  
  * Stage:
  * Prod:

## Operations Documents

TBD
